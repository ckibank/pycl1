# import requests

# environment variables

import os
from dotenv import load_dotenv

load_dotenv()

print(os.getenv("BHCL"))
print(os.getenv("MYSECRET"))
print(os.getenv("DBNAME"))

# how to check if a file exists in the current directory
print(f'apps.py exists = {os.path.exists("apps.py")}')
print(f'app.py exists = {os.path.exists("app.py")}')

# Print contents of readme.md
fname = "readme.md"

print("-"*40)


try:
  with open(fname, "r") as f:
    contents = f.read()
    print(contents)
# except:
  # print("There is an error reading the file")
except Exception as err:
  print(f"Can not read file, error = {err}")
finally:
  print("--- File handling completed")

a="3"
b=7

print("-"*40)
try:
  print(a+b)
except Exception as err:
  print("Error with a+b", err)