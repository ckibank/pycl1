# Dictionary - { Key : Value, Key2 : Value2 }
e = {
  "id" : 2334,
  "name" : "John",
  "contact": {
    "em1" : ["john@em1.com", "j2@em.com"],
    "ph" : "98989686"
  },
  "subj" : ["Fin", "Tech","Comm"]
}

print(e)
print("-"*40)
print("Name:", e["name"])

# John's identification is 2334
# Type casting in Python using str(), int(), float(), list() ......

print(e["name"] + "'s identification is " + str(e["id"]) )
print(e["name"] , "'s identification is", e["id"])

# Formatted string
to_print = f"{e['name']}'s identification is {e['id']}"
print(to_print)

# John's phone number is: xxxxxx
print(f"{e['name']}'s phone number is: {e['contact']['ph']}")
print(f"{e['name']}'s phone number is: {e['contact']['em1'][1]}")

# John's second subject is: ----
greeting_one = "hello"
d = [1,"Two",3,4.23,"Five"]

print(type(greeting_one))
print(type(d))
print(type(e))

print("------- Looping through lists -----------")
print(d)

for xyz in d:
  print(xyz, type(xyz))
  print("  ---  ")

print("------- Looping through Dictionaries -----------")
e = {
  "id" : 2334,
  "name" : "John",
  "contact": {
    "em1" : ["john@em1.com", "j2@em.com"],
    "ph" : "98989686"
  },
  "subj" : ["Fin", "Tech","Comm"]
}

for key in e:
  # for value in key:
  print(key,type(key),e[key])
  
print("***************")

for key, valu in e.items():
  print(f"{key} = {valu}")