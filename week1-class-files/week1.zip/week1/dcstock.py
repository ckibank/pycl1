stock_prices = {
    'AAPL': [150.25, 152.10, 148.75, 151.50, 149.80],
    'MSFT': [280.50, 285.25, 282.75, 278.90, 283.60],
    'AMZN': [3250.00, 3280.50, 3220.75, 3260.25, 3240.10],
    'GOOG': [2750.75, 2780.25, 2760.50, 2770.10, 2765.80],
    'TSLA': [750.00, 760.50, 755.25, 745.80, 752.90]
}

# Print all the prices for each stock from the above dictionary

# Print the total value of each stock
# Find the average price of each stock

for k,v in stock_prices.items():
  avg = sum(v)/len(v)
  print(f"{k}  {(v)} : Total={sum(v):.2f} : Avg.={avg:.2f}")

# AAPL [$150.25,......] : Total=$752.40  : Avg.=$150.48
