# Lists in Python

greeting_one = "hello"
greeting_two = "there"

# naming variables in Python
# greeting_one = 2 # snake case
greetingOne = 3 # Camel case
GreetingOne = 4 # Pascal case

print(greeting_one)
print(greetingOne)
print(GreetingOne)

# exit()

# List
#    0,1    ,2, 3.....
d = [1,"Two",3,4.23,"Five"]
#              -2  ,-1
print(d[0],"should print: 1")
print(d[4],"should print: Five")
print(d[-1],"should print: Five")

print("Slicing lists")
print(d[2:-1])

# dynamically typed

# print(s,s1)
# print(s+s1)
print(type(greeting_one))
print(type(d))

# this is a comment